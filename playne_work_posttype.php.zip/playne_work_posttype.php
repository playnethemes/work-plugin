<?php
/**
 * Work portfolio post type
 */
function playne_work_posttype() {

	$playne_work_labels = array(
		'name' => _x('work', 'post type general name', 'playne'),
		'singular_name' => _x('work', 'post type singular name', 'playne'),
		'add_new' => _x('Add New', 'work', 'playne'),
		'add_new_item' => __('Add New work', 'playne'),
		'edit_item' => __('Edit work', 'playne'),
		'new_item' => __('New work', 'playne'),
		'view_item' => __('View Client', 'playne'),
		'search_items' => __('Search work', 'playne'),
		'not_found' =>  __('No work found', 'playne'),
		'not_found_in_trash' => __('No work found in Trash', 'playne'),
		'parent_item_colon' => '',
		'menu_name' => 'Work'
	);
	
	$playne_work_args = array(
		'labels' => $playne_work_labels,
		'public' => true,
		'publicly_queryable' => true,
		'show_ui' => true,
		'menu_icon' => 'dashicons-images-alt',
		'show_in_menu' => true,
		'query_var' => true,
		'rewrite' => true,
		'capability_type' => 'post',
		'has_archive' => true,
		'hierarchical' => false,
		'menu_position' => null,
		'supports' => array('title','editor','author','thumbnail', 'excerpt')
	);
	// The following is the main step where we register the post.
	register_post_type('work',$playne_work_args);

	// Initialize New Taxonomy Labels
	$playne_work_category_labels = array(
		'name' => _x( 'Categories', 'taxonomy general name', 'playne' ),
		'singular_name' => _x( 'Category', 'taxonomy singular name', 'playne' ),
		'search_items' =>  __( 'Search Categories', 'playne' ),
		'all_items' => __( 'All Categories', 'playne' ),
		'parent_item' => __( 'Parent Category', 'playne' ),
		'parent_item_colon' => __( 'Parent Category:', 'playne' ),
		'edit_item' => __( 'Edit Categories', 'playne' ),
		'update_item' => __( 'Update Category', 'playne' ),
		'add_new_item' => __( 'Add New Category', 'playne' ),
		'new_item_name' => __( 'New Category Name', 'playne' ),
	);

	// Custom taxonomy for Project Tags
	register_taxonomy('work-categories',array('work'), array(
		'hierarchical' => true,
		'labels' => $playne_work_category_labels,
		'show_ui' => true,
		'query_var' => true,
		'rewrite' => array( 'slug' => 'categories' ),
	));
}
add_action('init', 'playne_work_posttype');